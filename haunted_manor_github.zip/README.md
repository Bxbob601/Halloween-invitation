# The Haunted Manor — Halloween Invitation

A single-file GitHub Pages prototype for a cinematic gothic Halloween dinner invitation.

Open `index.html` locally or deploy the repository with GitHub Pages.
